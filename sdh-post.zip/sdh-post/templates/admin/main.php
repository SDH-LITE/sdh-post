<div class="wrap">
    <h2><?php echo get_admin_page_title() ?></h2>
</div>

