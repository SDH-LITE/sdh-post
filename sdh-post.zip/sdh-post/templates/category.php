<?php
get_header(); // Включите шапку сайта
echo do_shortcode('[sdh-posts]');
get_footer();