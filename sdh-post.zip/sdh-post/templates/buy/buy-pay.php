<div class="card-header text-center">
    <?=esc_html__('Payment for the goods', 'sdh-post')?>
</div>
<div class="card-body text-center">
    <a target="_blank" href="<?=$payment_link?>">
        <button type="button" class="btn btn-outline-primary">
            <?=esc_html__('Link for payment', 'sdh-post')?>
        </button>
    </a>
</div>