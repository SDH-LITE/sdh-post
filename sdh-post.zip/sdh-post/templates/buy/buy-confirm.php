<div class="card-header text-center">
    <?=esc_html__('The product is purchased', 'sdh-post')?>
</div>
<div class="card-body text-center">
    <a target="_blank" href="<?=$link_download?>">
        <button type="button" class="btn btn-outline-primary">
            <?=esc_html__('Your download link', 'sdh-post')?>
        </button>
    </a>
</div>