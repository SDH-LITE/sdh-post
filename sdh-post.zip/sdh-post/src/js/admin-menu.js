jQuery(document).ready(function($) {

    $('.tabs').tabs();
    $(".button-collapse").sideNav();

});
